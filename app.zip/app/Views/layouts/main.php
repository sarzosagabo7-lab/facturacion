<!DOCTYPE html>
<html lang="es">

<!-- ==========================================
     HEAD
     ========================================== -->
<?= $this->include('layouts/components/head') ?>

<body class="layout-fixed sidebar-expand-lg">

<div class="app-wrapper">

    <!-- ==========================================
         NAVBAR
         ========================================== -->
    <?= $this->include('layouts/components/navbar') ?>

    <!-- ==========================================
         SIDEBAR
         ========================================== -->
    <?= $this->include('layouts/components/sidebar') ?>

    <!-- ==========================================
         CONTENIDO PRINCIPAL
         ========================================== -->
    <main class="app-main">

        <!-- ======================================
             HEADER
             ====================================== -->
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="page-title mb-0">
                            <?= $this->renderSection('page_title') ?>
                        </h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- ======================================
             CONTENIDO DINÁMICO
             ====================================== -->
        <div class="app-content">
            <div class="container-fluid">
                <?= $this->renderSection('content') ?>
            </div>
        </div>

    </main>

    <!-- ==========================================
         FOOTER
         ========================================== -->
    <?= $this->include('layouts/components/footer') ?>

</div>

<!-- ==========================================
     SCRIPTS
     ========================================== -->
<?= $this->include('layouts/components/scripts') ?>

<!-- ==========================================
     ESTILOS PERSONALIZADOS (EMERALD SLATE THEMING)
     ========================================== -->
<style>
    /* ==========================================
       VARIABLES DE COLOR
       ========================================== */
    :root {
        --bg-main: #0b0f19;
        --surface-dark: #111827;
        --border-color: rgba(255, 255, 255, 0.08);
        --accent-emerald: #10b981;
        --accent-teal: #14b8a6;
        --text-primary: #f3f4f6;
        --text-muted: #9ca3af;
    }

    /* ==========================================
       FONDO GENERAL
       ========================================== */
    body {
        background: 
            radial-gradient(
                circle at 15% 15%, 
                rgba(16, 185, 129, 0.12), 
                transparent 35%
            ),
            radial-gradient(
                circle at 85% 85%, 
                rgba(14, 165, 233, 0.10), 
                transparent 35%
            ),
            linear-gradient(
                135deg, 
                #0b0f19 0%, 
                #111827 50%, 
                #0f172a 100%
            ) !important;
        color: var(--text-primary);
        font-family: system-ui, -apple-system, sans-serif;
    }

    /* ==========================================
       WRAPPER
       ========================================== */
    .app-wrapper {
        background: transparent !important;
    }

    /* ==========================================
       NAVBAR (Glassmorphism)
       ========================================== */
    .app-header {
        background: rgba(17, 24, 39, 0.75) !important;
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border-bottom: 1px solid var(--border-color) !important;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    }

    .app-header .nav-link {
        color: var(--text-muted) !important;
        transition: color 0.2s ease;
    }

    .app-header .nav-link:hover {
        color: var(--accent-emerald) !important;
    }

    /* ==========================================
       SIDEBAR
       ========================================== */
    .app-sidebar {
        background: linear-gradient(
            180deg, 
            #111827 0%, 
            #0f172a 100%
        ) !important;
        border-right: 1px solid var(--border-color);
        box-shadow: 4px 0 24px rgba(0, 0, 0, 0.4);
    }

    /* ==========================================
       LOGO DEL SIDEBAR
       ========================================== */
    .app-sidebar .sidebar-brand {
        background: linear-gradient(
            90deg, 
            #064e3b, 
            #0f766e
        ) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .app-sidebar .sidebar-brand .brand-text {
        color: #ffffff !important;
        font-weight: 700;
        letter-spacing: 0.5px;
    }

    /* ==========================================
       OPCIONES DEL SIDEBAR
       ========================================== */
    .app-sidebar .nav-link {
        color: var(--text-muted) !important;
        border-radius: 8px;
        margin: 4px 12px;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .app-sidebar .nav-link .nav-icon {
        color: #6b7280 !important;
        transition: color 0.2s ease;
    }

    /* HOVER */
    .app-sidebar .nav-link:hover {
        background: rgba(16, 185, 129, 0.12) !important;
        color: #ffffff !important;
        transform: translateX(4px);
    }

    .app-sidebar .nav-link:hover .nav-icon {
        color: var(--accent-emerald) !important;
    }

    /* OPCIÓN ACTIVA */
    .app-sidebar .nav-link.active {
        background: linear-gradient(
            90deg, 
            #059669, 
            #0d9488
        ) !important;
        color: #ffffff !important;
        font-weight: 600;
        box-shadow: 0 4px 14px rgba(16, 185, 129, 0.35);
    }

    .app-sidebar .nav-link.active .nav-icon {
        color: #ffffff !important;
    }

    /* ==========================================
       TÍTULOS DEL MENÚ
       ========================================== */
    .app-sidebar .nav-header {
        color: #34d399 !important;
        font-weight: 700;
        font-size: 0.70rem;
        letter-spacing: 1.2px;
        text-transform: uppercase;
    }

    /* ==========================================
       CONTENIDO PRINCIPAL
       ========================================== */
    .app-main,
    .app-content-header,
    .app-content {
        background: transparent !important;
    }

    .page-title {
        color: #ffffff !important;
        font-weight: 700;
        letter-spacing: -0.02em;
    }

    /* ==========================================
       FOOTER
       ========================================== */
    .app-footer {
        background: rgba(17, 24, 39, 0.8) !important;
        border-top: 1px solid var(--border-color) !important;
        color: var(--text-muted) !important;
    }

    .app-footer strong {
        color: var(--accent-emerald);
    }

    /* ==========================================
       SCROLLBAR
       ========================================== */
    ::-webkit-scrollbar {
        width: 6px;
    }

    ::-webkit-scrollbar-track {
        background: #0b0f19;
    }

    ::-webkit-scrollbar-thumb {
        background: linear-gradient(#059669, #0891b2);
        border-radius: 8px;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(#10b981, #06b6d4);
    }
</style>

</body>
</html>