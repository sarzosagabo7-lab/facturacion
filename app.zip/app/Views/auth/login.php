<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión | Sistema de Facturación</title>

    <!-- Bootstrap Icons & Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/adminlte/dist/css/adminlte.min.css') ?>">

    <style>
        :root {
            --bg-dark: #0a0a0a;
            --card-bg: rgba(18, 18, 20, 0.92);
            --border-color: #27272a;
            --accent-red: #dc2626;
            --accent-red-hover: #b91c1c;
            --text-light: #f4f4f5;
            --text-muted: #a1a1aa;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: var(--bg-dark);
            /* IMAGEN DE FONDO */
            background-image: linear-gradient(rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0.85)), url('<?= base_url("assets/img/fondo_login.jpg") ?>');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: var(--text-light);
            overflow-x: hidden;
        }

        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-card {
            width: 100%;
            max-width: 410px;
            padding: 40px 32px;
            border-radius: 16px;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 8px 10px -6px rgba(220, 38, 38, 0.1);
            backdrop-filter: blur(12px);
            animation: fadeIn 0.4s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(12px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .logo {
            width: 64px;
            height: 64px;
            margin: 0 auto 16px auto;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 14px;
            background: rgba(220, 38, 38, 0.12);
            color: var(--accent-red);
            font-size: 30px;
            border: 1px solid rgba(220, 38, 38, 0.3);
            box-shadow: 0 0 15px rgba(220, 38, 38, 0.2);
        }

        .title {
            color: var(--text-light);
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .subtitle {
            color: var(--text-muted);
            font-size: 14px;
            margin-bottom: 28px;
        }

        .field {
            margin-bottom: 20px;
        }

        .field label {
            display: block;
            color: #d4d4d8;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
        }

        .input-box {
            display: flex;
            align-items: center;
            height: 48px;
            border-radius: 8px;
            background: #18181b;
            border: 1px solid var(--border-color);
            transition: all 0.15s ease-in-out;
        }

        .input-box i {
            color: var(--text-muted);
            font-size: 18px;
            width: 44px;
            text-align: center;
        }

        .input-box input {
            width: 100%;
            height: 100%;
            border: none;
            outline: none;
            background: transparent;
            color: var(--text-light);
            padding-right: 14px;
            font-size: 14px;
        }

        .input-box input::placeholder {
            color: #52525b;
        }

        .input-box:focus-within {
            border-color: var(--accent-red);
            box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.25);
        }

        .input-box:focus-within i {
            color: var(--accent-red);
        }

        .btn-login {
            width: 100%;
            height: 48px;
            border: none;
            border-radius: 8px;
            color: #ffffff;
            font-size: 15px;
            font-weight: 600;
            background-color: var(--accent-red);
            transition: background-color 0.15s ease-in-out, transform 0.1s ease;
            margin-top: 8px;
            box-shadow: 0 4px 12px rgba(220, 38, 38, 0.3);
        }

        .btn-login:hover {
            background-color: var(--accent-red-hover);
        }

        .btn-login:active {
            transform: scale(0.99);
        }

        .custom-alert {
            background: rgba(127, 29, 29, 0.4);
            color: #fca5a5;
            border: 1px solid #991b1b;
            border-radius: 8px;
            font-size: 13px;
            padding: 12px;
        }

        .footer {
            text-align: center;
            color: var(--text-muted);
            font-size: 12px;
            margin-top: 28px;
            padding-top: 18px;
            border-top: 1px solid var(--border-color);
        }

        .footer strong {
            color: var(--text-light);
        }
    </style>
</head>

<body>

<div class="login-container">
    <div class="login-card">

        <div class="text-center">
            <div class="logo">
                <i class="bi bi-receipt"></i>
            </div>
            <h1 class="title">Facturación App</h1>
            <p class="subtitle">Acceso exclusivo para administradores</p>
        </div>

        <!-- Alerta si las credenciales fallan -->
        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert custom-alert mb-4 d-flex align-items-center">
                <i class="bi bi-exclamation-circle-fill me-2 fs-5"></i>
                <div><?= session()->getFlashdata('error') ?></div>
            </div>
        <?php endif; ?>

        <form action="<?= base_url('login/authenticate') ?>" method="post" autocomplete="off">
            <?= csrf_field() ?>

            <div class="field">
                <label for="username">Usuario</label>
                <div class="input-box">
                    <i class="bi bi-person"></i>
                    <input type="text" name="username" id="username" placeholder="admin" required autofocus>
                </div>
            </div>

            <div class="field">
                <label for="password">Contraseña</label>
                <div class="input-box">
                    <i class="bi bi-lock"></i>
                    <input type="password" name="password" id="password" placeholder="••••••••" required>
                </div>
            </div>

            <button type="submit" class="btn-login">
                <i class="bi bi-box-arrow-in-right me-1"></i> Iniciar Sesión
            </button>
        </form>

        <div class="footer">
            © <?= date('Y') ?> <strong>Kleyder Company</strong>. Todos los derechos reservados.
        </div>
    </div>
</div>

</body>
</html>