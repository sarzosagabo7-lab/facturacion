<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Configuración por defecto
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();

// --------------------------------------------------------------------
// Rutas Públicas (Login y Sesión)
// --------------------------------------------------------------------
$routes->get('login', 'AuthController::index');
$routes->post('login/authenticate', 'AuthController::authenticate');
$routes->get('logout', 'AuthController::logout');

// --------------------------------------------------------------------
// Rutas Protegidas - VISTAS / NAVEGACIÓN (Requieren solo autenticación)
// --------------------------------------------------------------------
$routes->group('', ['filter' => 'auth'], function ($routes) {

    // Inicio / Dashboard / Facturación
    $routes->get('/', 'Home::index');
    $routes->get('facturacion', 'Home::index');

    // --- MÓDULO CATEGORÍAS (Carga de vistas web) ---
    $routes->get('categorias', 'CategoriaController::index');
    $routes->get('categoria', 'CategoriaController::index');
    $routes->get('usuarios', 'UsuarioController::index');
    $routes->get('usuario', 'UsuarioController::index');
    // --- MARCAS ---
    $routes->get('marcas', 'MarcaController::index');
    $routes->get('marca', 'MarcaController::index');

    // --- CLIENTES ---
    $routes->get('clientes', 'ClienteController::index');
    $routes->get('cliente', 'ClienteController::index');

    // --- PROVEEDORES ---
    $routes->get('proveedores', 'ProveedorController::index');
    $routes->get('proveedor', 'ProveedorController::index');
    $routes->get('productos', 'ProductoController::index');
    $routes->get('producto', 'ProductoController::index');

    $routes->get('facturas', 'VentaController::index');
    $routes->get('facturas/nueva', 'VentaController::nueva');
    $routes->get('facturas/ver/(:num)', 'VentaController::ver/$1');

});

// --------------------------------------------------------------------
// Rutas Protegidas - ACCIONES AJAX (Requieren autenticación Y petición AJAX)
// --------------------------------------------------------------------
$routes->group('', ['filter' => ['auth', 'ajax']], function ($routes) {

    // --- MÓDULO CATEGORÍAS (Operaciones CRUD vía AJAX) ---
    // Plural (/categorias)
    $routes->post('categorias/guardar', 'CategoriaController::store');
    $routes->post('categorias/actualizar/(:num)', 'CategoriaController::update/$1');
    $routes->post('categorias/eliminar/(:num)', 'CategoriaController::delete/$1');

    // Singular (/categoria)
    $routes->post('categoria/guardar', 'CategoriaController::store');
    $routes->post('categoria/actualizar/(:num)', 'CategoriaController::update/$1');
    $routes->post('categoria/eliminar/(:num)', 'CategoriaController::delete/$1');

});
$routes->group('', ['filter' => ['auth', 'ajax']], function ($routes) {
    // ... rutas existentes ...

    // --- MÓDULO USUARIOS (CRUD AJAX) ---
    // Plural (/usuarios)
    $routes->post('usuarios/guardar', 'UsuarioController::store');
    $routes->post('usuarios/actualizar/(:num)', 'UsuarioController::update/$1');
    $routes->post('usuarios/eliminar/(:num)', 'UsuarioController::delete/$1');

    // Singular (/usuario)
    $routes->post('usuario/guardar', 'UsuarioController::store');
    $routes->post('usuario/actualizar/(:num)', 'UsuarioController::update/$1');
    $routes->post('usuario/eliminar/(:num)', 'UsuarioController::delete/$1');
});
$routes->group('', ['filter' => ['auth', 'ajax']], function ($routes) {
    // --- MARCAS ---
    $routes->post('marcas/guardar', 'MarcaController::store');
    $routes->post('marcas/eliminar/(:num)', 'MarcaController::delete/$1');
    $routes->post('marca/guardar', 'MarcaController::store');
    $routes->post('marca/eliminar/(:num)', 'MarcaController::delete/$1');

    // --- CLIENTES ---
    $routes->post('clientes/guardar', 'ClienteController::store');
    $routes->post('clientes/eliminar/(:num)', 'ClienteController::delete/$1');
    $routes->post('cliente/guardar', 'ClienteController::store');
    $routes->post('cliente/eliminar/(:num)', 'ClienteController::delete/$1');

    // --- PROVEEDORES ---
    $routes->post('proveedores/guardar', 'ProveedorController::store');
    $routes->post('proveedores/eliminar/(:num)', 'ProveedorController::delete/$1');
    $routes->post('proveedor/guardar', 'ProveedorController::store');
    $routes->post('proveedor/eliminar/(:num)', 'ProveedorController::delete/$1');
});
$routes->group('', ['filter' => ['auth', 'ajax']], function ($routes) {
    $routes->post('productos/guardar', 'ProductoController::store');
    $routes->post('productos/eliminar/(:num)', 'ProductoController::delete/$1');
    $routes->post('producto/guardar', 'ProductoController::store');
    $routes->post('producto/eliminar/(:num)', 'ProductoController::delete/$1');
});
$routes->group('', ['filter' => ['auth', 'ajax']], function ($routes) {
    $routes->get('facturas/buscar-cliente', 'VentaController::buscarCliente');
    $routes->get('facturas/buscar-producto', 'VentaController::buscarProducto');
    $routes->post('facturas/guardar', 'VentaController::guardar');
});